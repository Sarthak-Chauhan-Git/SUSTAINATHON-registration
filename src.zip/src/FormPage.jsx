import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Header from "./components/Header";
import Progress from "./components/Progress";
import TeamInfo from "./components/TeamInfo";
import TeamLeadInfo from "./components/TeamLeadInfo";
import MemberInfo from "./components/MemberInfo";
import AdditionalMember from "./components/AdditionalMember";
import ProjectDetail from "./components/ProjectDetail";
import SuccessModel from "./components/SuccessModel";

function App() {
  return (
    <Router>
      <Header />
      <Progress />

      <div className="form-container">
        <Routes>
          <Route path="/" element={<Navigate to="/step1" />} />
          <Route path="/step1" element={<TeamInfo />} />
          <Route path="/step2" element={<TeamLeadInfo />} />
          <Route path="/step3" element={<MemberInfo />} />
          <Route path="/step4" element={<AdditionalMember />} />
          <Route path="/step5" element={<ProjectDetail />} />
          <Route path="/success" element={<SuccessModel />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
